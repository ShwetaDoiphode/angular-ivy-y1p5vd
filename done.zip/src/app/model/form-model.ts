export class FormModel {
  constructor(public zip: any) {}
}
